// src/popup/popup.ts
var REPO_URL = "https://github.com/noticedso/relationships-extension";
var NOTICED_ORIGIN = "https://www.noticed.so";
function openConnect() {
  const url = `${NOTICED_ORIGIN}/x/connect?ext_id=${chrome.runtime.id}`;
  if (chrome.tabs?.create) void chrome.tabs.create({ url });
  else window.open(url, "_blank");
}
function wireOnce(el, fn) {
  if (el && el.dataset.wired !== "1") {
    el.dataset.wired = "1";
    el.addEventListener("click", fn);
  }
}
function isDevBuild() {
  return false;
}
function setText(root, id, text) {
  const el = root.querySelector(`#${id}`);
  if (el) el.textContent = text;
}
function formatDate(ms) {
  return new Intl.DateTimeFormat(void 0, { dateStyle: "medium" }).format(new Date(ms));
}
async function getStatus() {
  return await chrome.runtime.sendMessage({ type: "getStatus" });
}
async function getSyncHistory() {
  return await chrome.runtime.sendMessage({ type: "getSyncHistory" });
}
function prettifySource(source) {
  return source.split("_").map((w) => w ? w[0].toUpperCase() + w.slice(1) : w).join(" ");
}
function renderSyncs(root, runs) {
  const list = root.querySelector("#sync-list");
  const empty = root.querySelector("#sync-empty");
  const more = root.querySelector("#sync-more");
  if (!list || !empty || !more) return;
  if (runs.length === 0) {
    list.replaceChildren();
    empty.hidden = false;
    more.hidden = true;
    return;
  }
  empty.hidden = true;
  const dateFmt = new Intl.DateTimeFormat(void 0, { day: "numeric", month: "short" });
  const buildRow = (r) => {
    const li = document.createElement("li");
    li.className = "sync-row";
    const stamp = r.finishedAt ?? r.startedAt;
    let when = "";
    if (stamp) {
      const d = new Date(stamp);
      if (!Number.isNaN(d.getTime())) when = dateFmt.format(d);
    }
    const count = typeof r.itemCount === "number" ? `${r.itemCount} ` : "";
    li.textContent = `${r.label ?? prettifySource(r.source)} \xB7 ${count}${r.kind ?? "items"}${when ? ` \xB7 ${when}` : ""}`;
    if (r.status && r.status !== "succeeded") li.dataset.status = r.status;
    return li;
  };
  list.replaceChildren(...runs.slice(0, 3).map(buildRow));
  const rest = runs.slice(3);
  more.hidden = rest.length === 0;
  const next = more.cloneNode(true);
  more.replaceWith(next);
  next.addEventListener("click", () => {
    for (const r of rest) list.appendChild(buildRow(r));
    next.hidden = true;
  });
}
function render(root, status) {
  setText(root, "account-name", status.account?.name ?? "your noticed account");
  setText(root, "account-email", status.account?.email ?? "");
  if (status.nextScanAt) {
    setText(root, "next-scan", `next scan: ${formatDate(status.nextScanAt)}`);
  } else {
    setText(root, "next-scan", "next scan: after your first sync");
  }
  if (status.lastScanAt) {
    const count = status.lastScanCount ?? 0;
    setText(root, "last-scan", `${count} connections synced \u2014 ${formatDate(status.lastScanAt)}`);
  } else {
    setText(root, "last-scan", "no sync yet");
  }
  const label = status.recipe?.networkLabel ?? "professional network";
  setText(
    root,
    "what-we-fetch",
    `we read your ${label} connection list \u2014 name, headline, profile link, connection date \u2014 as you, paced like a human, about once a month. we never read messages or anything else.`
  );
  setText(
    root,
    "privacy",
    "everything goes only to your noticed account over an encrypted connection. we never sell it, share it, or train AI on it. this extension holds no password and no noticed login \u2014 it hands data to your own signed-in noticed tab."
  );
  if (status.needs === "network-signin") {
    const label2 = status.recipe?.networkLabel ?? "your professional network";
    setText(root, "needs", `sign in to ${label2} so we can read your connections.`);
  } else if (status.needs === "noticed-signin") {
    setText(root, "needs", "sign in to noticed to finish syncing.");
  } else {
    setText(root, "needs", "");
  }
  const repo = root.querySelector("#repo-link");
  if (repo) repo.href = REPO_URL;
}
async function init(root = document) {
  if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) return;
  const button = root.querySelector("#scan-now");
  if (button && button.dataset.wired !== "1") {
    button.dataset.wired = "1";
    button.addEventListener("click", () => {
      void (async () => {
        const { recipe } = await getStatus();
        const origin = recipe?.targetOrigin;
        if (origin) {
          const granted = await chrome.permissions.request({
            origins: [`${origin}/*`]
          });
          if (!granted) {
            await init(root);
            return;
          }
        }
        await chrome.runtime.sendMessage({ type: "scanNow" });
        await init(root);
      })();
    });
  }
  const status = await getStatus();
  const connected = Boolean(status.recipe || status.account);
  const connectSection = root.querySelector("#connect");
  if (connectSection) connectSection.hidden = connected;
  for (const sel of ["#account", "#what-we-fetch", "#privacy", "#syncs"]) {
    const el = root.querySelector(sel);
    if (el) el.hidden = !connected;
  }
  const statusCard = root.querySelector(".status");
  if (statusCard) statusCard.hidden = !connected;
  wireOnce(root.querySelector("#connect-cta"), openConnect);
  render(root, status);
  if (!connected) return;
  const history = await getSyncHistory();
  const signin = root.querySelector("#signin-cta");
  if (history?.needs === "noticed-signin") {
    if (signin) signin.hidden = false;
    wireOnce(signin, openConnect);
    setText(root, "needs", "");
    renderSyncs(root, []);
  } else {
    if (signin) signin.hidden = true;
    renderSyncs(root, history?.runs ?? []);
  }
  if (isDevBuild()) {
    const toggleWrap = root.querySelector("#test-mode-toggle");
    if (toggleWrap) toggleWrap.hidden = false;
    const testMode = root.querySelector("#test-mode");
    if (testMode) {
      testMode.checked = Boolean(status.testMode);
      if (testMode.dataset.wired !== "1") {
        testMode.dataset.wired = "1";
        testMode.addEventListener("change", () => {
          void chrome.runtime.sendMessage({ type: "setTestMode", value: testMode.checked });
        });
      }
    }
  }
}
if (typeof document !== "undefined" && typeof window !== "undefined") {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => void init());
  } else {
    void init();
  }
}
export {
  init
};
