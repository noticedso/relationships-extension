var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/lib/fetch-engine.ts
var fetch_engine_exports = {};
__export(fetch_engine_exports, {
  scanConnections: () => scanConnections
});
async function scanConnections(opts) {
  const { fetchPage, pageSize, maxPages, sleep, jitter } = opts;
  const all = [];
  let start = 0;
  for (let page = 0; page < maxPages; page++) {
    const items = await fetchPage(start);
    all.push(...items);
    const lastPage = items.length < pageSize;
    const capReached = page + 1 >= maxPages;
    if (lastPage || capReached) break;
    await sleep(jitter());
    start += pageSize;
  }
  return all;
}
var init_fetch_engine = __esm({
  "src/lib/fetch-engine.ts"() {
    "use strict";
  }
});

// src/lib/cookies.ts
function stripWrappingQuotes(value) {
  if (value.length >= 2 && value.startsWith('"') && value.endsWith('"')) {
    return value.slice(1, -1);
  }
  return value;
}
async function buildCsrfHeaders(recipe) {
  const chrome2 = globalThis.chrome;
  const cookie = await chrome2.cookies.get({
    url: recipe.targetOrigin,
    name: recipe.csrfRule.cookie
  });
  if (!cookie || typeof cookie.value !== "string" || cookie.value.trim() === "") {
    return null;
  }
  return { [recipe.csrfRule.header]: stripWrappingQuotes(cookie.value) };
}

// src/lib/recipe.ts
function getByPath(obj, path) {
  let current = obj;
  for (const key of path.split(".")) {
    if (current === null || current === void 0 || typeof current !== "object") {
      return void 0;
    }
    current = current[key];
  }
  return current;
}
function toStringOrNull(value) {
  if (value === null || value === void 0) return null;
  if (typeof value === "string") return value.length > 0 ? value : null;
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  return null;
}
function toConnectedOn(value) {
  if (typeof value === "number") {
    if (!Number.isFinite(value)) return null;
    const d = new Date(value);
    if (isNaN(d.getTime())) return null;
    return d.toISOString().slice(0, 10);
  }
  if (typeof value === "string") {
    return value;
  }
  return null;
}
function applyFieldMap(page, fieldMap) {
  const elements = getByPath(page, fieldMap.elementsPath);
  if (!Array.isArray(elements)) return [];
  const out = [];
  for (const element of elements) {
    const profileUrl = toStringOrNull(getByPath(element, fieldMap.profileUrl));
    if (!profileUrl) continue;
    out.push({
      profileUrl,
      firstName: toStringOrNull(getByPath(element, fieldMap.firstName)),
      lastName: toStringOrNull(getByPath(element, fieldMap.lastName)),
      headline: toStringOrNull(getByPath(element, fieldMap.headline)),
      connectedOn: fieldMap.connectedOn ? toConnectedOn(getByPath(element, fieldMap.connectedOn)) : null
    });
  }
  return out;
}

// src/lib/storage.ts
var KEYS = [
  "recipe",
  "account",
  "noticedOrigin",
  "pendingScan",
  "lastScanAt",
  "lastScanCount",
  "lastScanStartedAt",
  "needs",
  "testMode"
];
async function getState() {
  const raw = await chrome.storage.local.get(KEYS);
  return raw;
}
async function setState(patch) {
  await chrome.storage.local.set(patch);
}

// src/service-worker.ts
var SCAN_ALARM = "scan";
var SCAN_PERIOD_MINUTES = 43200;
var SCAN_PERIOD_MS = SCAN_PERIOD_MINUTES * 60 * 1e3;
var DAY_MS = 24 * 60 * 60 * 1e3;
var SCAN_THROTTLE_MS = SCAN_PERIOD_MS - DAY_MS;
var SYNC_PATH = "/x/sync";
function isNoticedOrigin(origin) {
  if (!origin) return false;
  try {
    const url = new URL(origin);
    return url.protocol === "https:" && /(^|\.)noticed\.so$/.test(url.hostname);
  } catch {
    return false;
  }
}
function senderOrigin(sender) {
  if (sender.origin) return sender.origin;
  if (sender.url) {
    try {
      return new URL(sender.url).origin;
    } catch {
      return null;
    }
  }
  return null;
}
var realSleep = (ms) => new Promise((r) => setTimeout(r, ms));
function makeJitter(recipe) {
  const { minDelayMs, maxDelayMs } = recipe.pacing;
  return () => minDelayMs + Math.random() * Math.max(0, maxDelayMs - minDelayMs);
}
function buildPageUrl(recipe, start) {
  const path = recipe.listPathTemplate.replaceAll("{start}", String(start)).replaceAll("{count}", String(recipe.paginationParams.pageSize));
  return recipe.targetOrigin + path;
}
async function runScan(deps = {}) {
  const fetchImpl = deps.fetchImpl ?? globalThis.fetch;
  const sleep = deps.sleep ?? realSleep;
  const { recipe, noticedOrigin, testMode } = await getState();
  if (!recipe) return { ok: false };
  const headers = await buildCsrfHeaders(recipe);
  if (!headers) {
    await setState({ needs: "network-signin" });
    return { ok: false, needs: "network-signin" };
  }
  const jitter = deps.jitter ?? makeJitter(recipe);
  const fetchPage = async (start) => {
    const res = await fetchImpl(buildPageUrl(recipe, start), {
      credentials: "include",
      headers
    });
    if (!res.ok) throw new Error(`scan page fetch failed: ${res.status}`);
    const json = await res.json();
    return applyFieldMap(json, recipe.fieldMap);
  };
  const effectiveMaxPages = testMode ? Math.min(2, recipe.pacing.maxPagesPerSession) : recipe.pacing.maxPagesPerSession;
  const { scanConnections: scanConnections2 } = await Promise.resolve().then(() => (init_fetch_engine(), fetch_engine_exports));
  const connections = await scanConnections2({
    fetchPage,
    pageSize: recipe.paginationParams.pageSize,
    maxPages: effectiveMaxPages,
    sleep,
    jitter
  });
  const startedAt = (deps.nowMs ?? (() => Date.now()))();
  if (!noticedOrigin) {
    await setState({ pendingScan: connections, needs: null, lastScanStartedAt: startedAt });
    return { ok: true, count: connections.length, note: "no-handoff-origin" };
  }
  await setState({
    pendingScan: connections,
    needs: "noticed-signin",
    lastScanStartedAt: startedAt
  });
  await chrome.tabs.create({ url: `${noticedOrigin}${SYNC_PATH}?ext_id=${chrome.runtime.id}` });
  return { ok: true, count: connections.length };
}
async function handleExternal(message, origin, sendResponse) {
  switch (message.type) {
    case "ping":
      sendResponse({ ok: true });
      return;
    case "pair":
      await setState({
        recipe: message.recipe,
        account: message.account,
        noticedOrigin: origin
      });
      chrome.alarms.create(SCAN_ALARM, { periodInMinutes: SCAN_PERIOD_MINUTES });
      sendResponse({ ok: true });
      return;
    case "getCachedScan": {
      const { pendingScan } = await getState();
      sendResponse({ connections: pendingScan ?? null });
      return;
    }
    case "syncConfirmed": {
      const { pendingScan } = await getState();
      const count = pendingScan?.length ?? 0;
      await setState({
        pendingScan: null,
        needs: null,
        lastScanAt: Date.now(),
        lastScanCount: count
      });
      sendResponse({ ok: true });
      return;
    }
  }
}
async function handleInternal(message, sendResponse) {
  switch (message.type) {
    case "getStatus": {
      const state = await getState();
      const lastScanAt = state.lastScanAt ?? null;
      const nextScanAt = lastScanAt != null ? lastScanAt + SCAN_PERIOD_MS : null;
      sendResponse({
        account: state.account ?? null,
        recipe: state.recipe ?? null,
        nextScanAt,
        lastScanAt,
        lastScanCount: state.lastScanCount ?? null,
        needs: state.needs ?? null,
        testMode: state.testMode ?? false
      });
      return;
    }
    case "scanNow": {
      const result = await runScan();
      sendResponse(result.ok ? { ok: true } : result);
      return;
    }
    case "setTestMode": {
      await setState({ testMode: message.value });
      sendResponse({ ok: true });
      return;
    }
    case "getSyncHistory": {
      const { noticedOrigin, recipe } = await getState();
      if (!noticedOrigin) {
        sendResponse({ runs: [] });
        return;
      }
      try {
        const res = await fetch(noticedOrigin + "/api/sync/runs", { credentials: "include" });
        if (res.status === 401) {
          sendResponse({ needs: "noticed-signin" });
          return;
        }
        if (!res.ok) {
          sendResponse({ runs: [], error: true });
          return;
        }
        const data = await res.json();
        const exclude = recipe?.excludeSources ?? [];
        const runs = (data.runs ?? []).filter((r) => !exclude.includes(r.source ?? ""));
        sendResponse({ runs });
      } catch {
        sendResponse({ runs: [], error: true });
      }
      return;
    }
  }
}
var registered = false;
var lastChrome;
function registerListeners() {
  if (typeof chrome === "undefined") return;
  if (registered && lastChrome === chrome) return;
  registered = true;
  lastChrome = chrome;
  chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
    const origin = senderOrigin(sender);
    if (!isNoticedOrigin(origin)) return;
    void handleExternal(message, origin, sendResponse);
    return true;
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    void handleInternal(message, sendResponse);
    return true;
  });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name !== SCAN_ALARM) return;
    void (async () => {
      const { lastScanStartedAt } = await getState();
      if (lastScanStartedAt != null && Date.now() - lastScanStartedAt < SCAN_THROTTLE_MS) return;
      await runScan();
    })();
  });
}
registerListeners();
export {
  isNoticedOrigin,
  registerListeners,
  runScan
};
